require "test_helper"

class RequestbookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
