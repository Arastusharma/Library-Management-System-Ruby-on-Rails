class Requestbook < ApplicationRecord
end
