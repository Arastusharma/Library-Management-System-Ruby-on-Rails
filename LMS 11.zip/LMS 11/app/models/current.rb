class Current < ActiveSupport::CurrentAttributes
	attribute :user
end