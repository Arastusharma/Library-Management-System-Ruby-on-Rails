module FacultyHelper
end
