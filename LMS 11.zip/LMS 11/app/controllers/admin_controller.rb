class AdminController < ApplicationController
  def dashboard
  end
end
