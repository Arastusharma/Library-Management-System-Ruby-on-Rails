class HomeController < ApplicationController
  

  def index    
  end  

  def about
  end

  def student
  end

  def Faculty
  end

  def Admin
  end
end
